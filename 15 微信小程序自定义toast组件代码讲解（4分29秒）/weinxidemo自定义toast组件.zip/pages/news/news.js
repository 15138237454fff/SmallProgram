

// pages/news/news.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title:'我是新闻组件的title'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.toast = this.selectComponent("#toast")
  },

  showToast: function () {
    this.toast.showToast('我是传过来的toast内容', 5000)
  }  
})