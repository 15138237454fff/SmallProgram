var WxParse = require('../../wxParse/wxParse.js');
var config = require('../../utils/config.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    host: config.host
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    //获取上一个页面的传值
    console.log(options);
    this.requestData(options.id);


    // var article = '<h2>我是HTML代码</h2>';
   
    // var that = this;
    // WxParse.wxParse('article', 'html', article, that, 5);



  },

  requestData(id){

    var that=this;
    var api = config.host+'api/productcontent?id=' + id;

    wx.request({
      url: api, //仅为示例，并非真实的接口地址     
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
     
        var data = res.data.result[0];
        data.img_url = data.img_url.replace(/\\/g,'/');

        //解析html
        var article = data.content;
        WxParse.wxParse('article', 'html', article, that, 5);


        that.setData({
          list: data
        })
      }
    })

  }

  
})