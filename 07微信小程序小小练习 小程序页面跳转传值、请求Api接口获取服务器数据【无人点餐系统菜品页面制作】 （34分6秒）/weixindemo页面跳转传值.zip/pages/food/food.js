// pages/food/food.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },
  goFoodContent(event){

    console.log(event.currentTarget.dataset.aid);

    var aid = event.currentTarget.dataset.aid;

    wx.navigateTo({
      url: '../foodcontent/foodcontent?aid=' + aid
    })
  }
  
})