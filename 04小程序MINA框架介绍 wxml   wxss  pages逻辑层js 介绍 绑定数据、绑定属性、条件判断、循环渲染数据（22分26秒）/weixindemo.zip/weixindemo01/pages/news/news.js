// pages/news/news.js
Page({

  /**
   * 页面的初始数据  
   */
  data: {
    msg:'我是业务逻辑里面的数据',
    obj:{
      name:'张三'
    },
    num:123,
    flag:false,
    aid: 12345,
    list:['111','222','3333','444'],
    list1: [

      {
        title:'新闻111'
      },
      {
        title: '新闻2222'
      },
      {
        title: '新闻3333'
      }
    ],
    list2: [

      {
        cate: '宝马',
        list: [
          {
            title: '宝马x1'
          },
          {
            title: '宝马x2'
          },
          {
            title: '宝马x3'
          },
          {
            title: '宝马x4'
          },
          {
            title: '宝马x5'
          },
        ]
      },
      {
        cate: '大众',
        list: [
          {
            title: '大众x1'
          },
          {
            title: '大众x2'
          },
           {
             title: '大众x3'
          },
           {
             title: '大众x4'
           },
            {
              title: '大众x5'
           },
        ]
      }
    ]
    

  }
})